Student name: Shashwat Adhikari
Student number: 300152636
Course code: ITI1121
Lab section: A00

This archive contains the 4 files of lab 11, that is, this file (README.txt),
plus Iterator.java, BitList.java, Iterative.java.